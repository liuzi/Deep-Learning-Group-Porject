|File_Name|Description|
|:----|:----|
|data/|image list of training set, validation set and test set|
|CS5242 FinalProject_DataProcessing.ipynb|codes of preprocessing which split all images into three sets|
|Several_Base_Models.ipynb|codes of several base models without finetune|
|Finetune_InceptionNetV2.ipynb|codes of finetuning the inceptionNetV2|
|Finetune_InceptionNetV2_BestResult.ipynb|codes of finetuned inceptionNetV2 with the best performance|
