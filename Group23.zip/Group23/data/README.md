## .csv files of 3 splited data: training set, validation set, test set
>- id: name of each image
>- breed id: id of each breed
>- breed: name of each breed

|file_name|description|
|:---:|:---|
|all_dogs.csv|all dogs, 20580|
|df_train|80%*80% of all dogs, 13171|
|df_val|80%*20% of all dogs, 3293|
|df_test|20% of all dogs, 4116| 
